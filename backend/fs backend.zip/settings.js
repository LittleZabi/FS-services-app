exports.DATABASE_HOST = "localhost";
exports.DATABASE_USER = "root";
exports.DATABASE_PASS = "";
exports.DATABASE_NAME = "FAST_u";
exports.emails_user = "zohaibjozvi@gmail.com";
exports.emails_pass = "csbihwfucstimmmr";
exports.SITE_NAME = "FS UNLOCKER";
exports.ROOT = "http://localhost:3006";
